package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.validator.ParamTypesValidator;
import com.salt.interview.service2.data.validator.ValidatorResult;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DateValidator implements ParamTypesValidator {

    // todo: move it to config
    private final String PATTERN = "dd-mm-yyyy";

    private static volatile DateValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the DateValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static DateValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (DateValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new DateValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        if (org.apache.commons.validator.routines.DateValidator.getInstance().validate(input.textValue(), PATTERN) == null) {
            return new ValidatorResult().addAbnormalField(name, String.format("Not a valid format date, should be: [%s]",  PATTERN));
        }
        return SUCCESS_RESULT;
    }


    @Override
    public String validatorName() { return ParamsTypes.Date.toString();}
}
