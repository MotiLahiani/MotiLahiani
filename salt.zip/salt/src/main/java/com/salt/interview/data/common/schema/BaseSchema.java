package com.salt.interview.data.common.schema;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.SchemaType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Set;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type", include = JsonTypeInfo.As.EXISTING_PROPERTY, visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = ValueSchema.class, name = "value"),
        @JsonSubTypes.Type(value = ArraySchema.class, name = "array"),
        @JsonSubTypes.Type(value = MethodSchema.class, name = "method"),
        @JsonSubTypes.Type(value = ObjectSchema.class, name = "object")
})

@Data
@SuperBuilder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonPropertyOrder({"type", "name", "fullPath", "paramsTypes"})
public abstract class BaseSchema {

    @JsonProperty(value = "name", required = true)
    protected String name;
    @JsonProperty(value = "fullPath", required = true)
    protected String fullPath;
    @JsonProperty(value = "paramTypes", required = true)
    protected Set<ParamsTypes> paramsTypes;

    @JsonProperty(value = "type", required = true)
    public abstract SchemaType getType();
}
