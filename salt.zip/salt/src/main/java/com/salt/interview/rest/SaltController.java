package com.salt.interview.rest;


import com.salt.interview.data.module.SaltModule;
import com.salt.interview.data.request.Request;
import com.salt.interview.s1.S1Handler;
import com.salt.interview.service2.S2Handler;
import com.salt.interview.service2.data.validator.ValidatorResult;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@RestController
@RequestMapping(value = "/interview",consumes = MediaType.APPLICATION_JSON_VALUE,  produces = MediaType.APPLICATION_JSON_VALUE)
public class SaltController {

    private final S1Handler s1Handler;
    private final S2Handler s2Handler;

    public SaltController(final S1Handler s1Handler, final S2Handler s2Handler) {

        this.s1Handler = s1Handler;
        this.s2Handler = s2Handler;
    }

    @PostMapping("/set/modules")
    public void setModulesHandler(@RequestBody Set<SaltModule> modules) {
        s1Handler.handleModules(modules);
    }

    @PostMapping("/validate")
    public ValidatorResult validateRequest(@RequestBody Request request) {
        return s2Handler.validateRequest(request);
    }

}
