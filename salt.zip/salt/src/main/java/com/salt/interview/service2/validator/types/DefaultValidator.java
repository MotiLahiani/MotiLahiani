package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ParamTypesValidator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DefaultValidator implements ParamTypesValidator {
    private static volatile DefaultValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the DefaultValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static DefaultValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (DefaultValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new DefaultValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid Type", input));
    }

    @Override
    public String validatorName() { return ParamsTypes.Boolean.toString();}


}
