package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ParamTypesValidator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class StringValidator implements ParamTypesValidator {
    private static volatile StringValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the StringValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static StringValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (StringValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new StringValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        //if (!org.apache.commons.validator.routines.getInstance().isValid(input)) {
        if(!input.isTextual()) {
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid String number but a %s type", input, input.getNodeType().name()));
        }
        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.String.toString();}
}
