package com.salt.interview.data.request;

public interface IRequest {

    String getPath();
}
