package com.salt.interview.data.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum SchemaType {

    // base key-value
    @JsonProperty("value")
    VALUE("value"),

    // method
    @JsonProperty("method")
    METHOD("method"),

    // Array
    @JsonProperty("array")
    ARRAY("array"),

    // Object
    @JsonProperty("object")
    OBJECT("object");

    private final String type;

    SchemaType(final String type) {
        this.type = type;
    }

}
