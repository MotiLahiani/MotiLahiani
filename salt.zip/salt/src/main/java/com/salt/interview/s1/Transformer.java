package com.salt.interview.s1;

import com.salt.interview.data.module.SaltModule;
import com.salt.interview.common.schema.ISchema;

public interface Transformer {

    ISchema transform(SaltModule module) ;
}
