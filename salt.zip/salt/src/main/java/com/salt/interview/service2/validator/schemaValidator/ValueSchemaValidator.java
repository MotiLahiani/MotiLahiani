package com.salt.interview.service2.validator.schemaValidator;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ValidatorFactory;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@EqualsAndHashCode
@ToString
public class ValueSchemaValidator implements SchemaTypeValidator {

    private static volatile ValueSchemaValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the ValueSchemaValidator.
     *
     * Use Lazy creation and double check locking
     */
    public static ValueSchemaValidator getInstance() {
        if (VALIDATOR == null) {
            synchronized (ValueSchemaValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new ValueSchemaValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult doValidate(BaseSchema schema, JsonNode node) {

        ValidatorResult validatorResult = new ValidatorResult();


        for(ParamsTypes type : schema.getParamsTypes()) {
            validatorResult.add(ValidatorFactory.getParamTypeValidator(type).validate(schema.getName(), node));
        }

        return validatorResult;
    }
}
