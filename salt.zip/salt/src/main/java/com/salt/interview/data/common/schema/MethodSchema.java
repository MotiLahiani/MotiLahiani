package com.salt.interview.data.common.schema;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.salt.interview.data.common.Method;
import com.salt.interview.data.common.SchemaType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonPropertyOrder({"type", "name", "fullPath", "paramsTypes", "method"})
public class MethodSchema extends BaseSchema {

    protected Method method;

    @Override
    public SchemaType getType() {
        return SchemaType.METHOD;
    }
}
