package com.salt.interview.service2.data.validator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ValidatorResult {
    public enum Status {
        Fail,
        Success
    }
    @Builder.Default
    private Status status = Status.Success;
    @Builder.Default
    private List<AbnormalField> abnormal = new ArrayList<>();

    @JsonIgnore
    public ValidatorResult addAbnormalField(final String name, final String reason) {
        status = Status.Fail;
        abnormal.add(AbnormalField.builder()
                .name(name)
                .reason(reason)
                .build()
        );
        return this;
    }

    @JsonIgnore
    public ValidatorResult add(ValidatorResult validatorResult) {
        status = validatorResult.getStatus().equals(Status.Fail) ? Status.Fail : status;
        abnormal.addAll(validatorResult.getAbnormal());
        return this;
    }
}
