package com.salt.interview.data.common.schema;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.SchemaType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Set;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonPropertyOrder({"type", "name", "fullPath", "paramsTypes"})
public class ValueSchema extends BaseSchema {

    @Override
    public SchemaType getType() {
        return SchemaType.VALUE;
    }
}
