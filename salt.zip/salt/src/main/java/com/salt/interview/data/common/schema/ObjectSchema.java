package com.salt.interview.data.common.schema;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.salt.interview.common.schema.ISchema;
import com.salt.interview.data.common.SchemaType;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonPropertyOrder({"type", "name", "fullPath", "paramsTypes", "requiredItems"})
public class ObjectSchema extends BaseSchema implements ISchema {

    @Setter(AccessLevel.NONE)
    @Builder.Default
    protected List<BaseSchema> requiredItems = new ArrayList<>();;

    @Override
    public SchemaType getType() {
        return SchemaType.OBJECT;
    }
}
