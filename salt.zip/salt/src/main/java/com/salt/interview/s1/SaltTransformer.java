package com.salt.interview.s1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.salt.interview.data.common.Method;
import com.salt.interview.data.module.Field;
import com.salt.interview.data.module.SaltModule;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.schema.ArraySchema;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.common.schema.ISchema;
import com.salt.interview.data.common.schema.MethodSchema;
import com.salt.interview.data.common.schema.ObjectSchema;
import com.salt.interview.data.common.schema.ValueSchema;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Service
public class SaltTransformer implements Transformer {

    private final ObjectMapper mapper;
    public SaltTransformer(final ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public ISchema transform(SaltModule module) {

        if (module == null) {
            return null;
        }
        JsonNode root = this.mapper.valueToTree(module);
        if (root == null) {
            return null;
        }

        //todo change to read all children fields and build according
        JsonNode pathNode = root.path("path");
        if (Objects.isNull(pathNode)) {
            // throw new Exception("Create exception");
        }
        List<BaseSchema> required = new ArrayList<>();
        required.add(createValueSchema("path", "path",Set.of(ParamsTypes.String)));
        JsonNode methodNode = root.path("method");
        required.add(createMethodSchema("method", "method", Set.of(ParamsTypes.String, ParamsTypes.Method), Method.valueOf(methodNode.textValue())));
        required.add(getSchemaArray("query_params", root.path("query_params")));
        required.add(getSchemaArray("headers", root.path("headers")));
        required.add(getSchemaArray("body", root.path("body")));

        return ObjectSchema.builder().name(pathNode.textValue()).requiredItems(required).build();

    }

    private BaseSchema getSchemaArray(String name, JsonNode node) {
        if (node == null || !node.isArray()) {
            return null;
        }

        List<BaseSchema> requiredList = new LinkedList<>();
        List<BaseSchema> optionalList = new LinkedList<>();

        Iterator<JsonNode> it = node.iterator();
        while(it.hasNext()) {
            JsonNode fieldNode = it.next();
            if(fieldNode.isObject()) {
                Field field;
                try {
                    field = mapper.treeToValue(fieldNode, Field.class);
                    ValueSchema vs = createValueSchema(field.getName(), field.getName()/*motiString.format("%s/%s",name, field.getName())*/, field.getTypes());
                    if(field.getRequired() != null && field.getRequired()) {
                        requiredList.add(vs);
                    } else {
                        optionalList.add(vs);
                    }
                } catch(JsonProcessingException e) {
                    //log
                    //current implementation do nothing
                }
            }
        }
        return createArraySchema(name, name, Set.of(ParamsTypes.Array),requiredList, optionalList);
    }

    private ValueSchema createValueSchema(final String name, final String fullPath, final Set<ParamsTypes> paramTypes) {
        return ValueSchema.builder().name(name).fullPath(fullPath).paramsTypes(paramTypes).build();
    }

    private MethodSchema createMethodSchema(final String name, final String fullPath, final Set<ParamsTypes> paramTypes, final Method method) {
        return MethodSchema.builder().name(name).fullPath(fullPath).paramsTypes(paramTypes).method(method).build();
    }

    private ArraySchema createArraySchema(final String name, final String fullPath, final Set<ParamsTypes> paramTypes,
                                          final List<BaseSchema> requiredItems, final List<BaseSchema> optionalSchemas) {
        return ArraySchema.builder().name(name).fullPath(fullPath).paramsTypes(paramTypes).requiredItems(requiredItems).optionalItems(optionalSchemas).build();
    }
}
