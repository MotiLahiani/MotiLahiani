package com.salt.interview.db;

import com.salt.interview.common.schema.ISchema;

import java.util.List;

public interface SchemaRepository {

    boolean insert(ISchema schema);
    boolean insertAll(List<ISchema> schemas);
    boolean remove(String key);
    boolean remove(ISchema schema);
    ISchema get(String key);

}
