package com.salt.interview.service2.validator.schemaValidator;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.service2.data.validator.ValidatorResult;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@EqualsAndHashCode(callSuper = true)
@ToString
public class MethodSchemaValidator extends ValueSchemaValidator {
    private static volatile MethodSchemaValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the MethodSchemaValidator.
     *
     * Use Lazy creation and double check locking
     */
    public static MethodSchemaValidator getInstance() {
        if (VALIDATOR == null) {
            synchronized (MethodSchemaValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new MethodSchemaValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult doValidate(BaseSchema schema, JsonNode node) {

        ValidatorResult validatorResult = new ValidatorResult();
        validatorResult.add(super.doValidate(schema, node));

        return validatorResult;
    }

}
