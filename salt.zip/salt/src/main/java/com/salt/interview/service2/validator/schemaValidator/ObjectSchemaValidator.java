package com.salt.interview.service2.validator.schemaValidator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.data.common.schema.ObjectSchema;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ValidatorFactory;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import java.util.List;

@EqualsAndHashCode
@ToString
public class ObjectSchemaValidator implements SchemaTypeValidator {

    protected Integer containRequired;

    private static volatile ObjectSchemaValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the ObjectSchemaValidator.
     *
     * Use Lazy creation and double check locking
     */
    public static ObjectSchemaValidator getInstance() {
        if (VALIDATOR == null) {
            synchronized (ObjectSchemaValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new ObjectSchemaValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult doValidate(BaseSchema schema, JsonNode node) {
        ValidatorResult validatorResult = new ValidatorResult();

        if (!node.isObject()) {
            return validatorResult.addAbnormalField(schema.getName(),
                    String.format("[%s] is not a valid Object but a %s type", node, node.getNodeType().name()));
        }

        this.containRequired = 0;

        checkRequired(schema, node, validatorResult);

        return validatorResult;
    }

    protected void checkRequired(BaseSchema schema, JsonNode node, ValidatorResult validatorResult) {
        checkItems(schema.getName(), node, validatorResult, ((ObjectSchema)schema).getRequiredItems(), containRequired, true);
    }

    protected void checkItems(String name, JsonNode node, ValidatorResult validatorResult, List<BaseSchema> items, Integer counter, boolean isRequierd) {
        for(BaseSchema bs : items) {

            if(isItemTypeAllowed(bs, validatorResult)) {

                JsonNode reqNode = find(node, bs.getName());
                //JsonNode reqNode = node.path(bs.getFullPath());
                boolean isExists = reqNode != null && !reqNode.isMissingNode();
                if (isRequierd && !isExists) {
                    validatorResult.addAbnormalField(name, String.format("[%s] required item not exists",
                            bs.getFullPath()));
                } else if((isRequierd && isExists) || (!isRequierd && isExists)) {
                    //check
                    counter++;
                    validatorResult.add(ValidatorFactory.getValidator(bs.getType()).doValidate(bs, reqNode));
                } else {
                    //!isRequierd && !isExists
                    continue;
                }
            }
        }
    }
    protected boolean isItemTypeAllowed(BaseSchema schema, ValidatorResult validatorResult) {
        return true;
    }

    protected JsonNode find(JsonNode node, String name) {

        for (JsonNode jsonNode : node) {

            if (jsonNode.get("name").asText().equals(name)) {
                return ((ObjectNode)jsonNode).get("value");
            }
        }
        return null;
    }
}
