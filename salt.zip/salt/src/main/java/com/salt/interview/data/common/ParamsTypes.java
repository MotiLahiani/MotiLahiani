package com.salt.interview.data.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum ParamsTypes {
    Int("Int"),
    String("String"),
    Boolean("Boolean"),
    Date("Date"),
    Email("Email"),
    UUID("String"),
    @JsonProperty("Auth-Token")
    AuthToken("Auth-Token"),
    List("List"),
    Method("Method"),
    Array("Array");

    private final String type;

    ParamsTypes(final String type) {
        this.type = type;
    }
}
