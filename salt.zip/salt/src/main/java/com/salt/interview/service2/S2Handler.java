package com.salt.interview.service2;

import com.salt.interview.data.request.IRequest;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.IRequestValidator;
import org.springframework.stereotype.Service;

@Service
public class S2Handler {

    private final IRequestValidator requestValidator;

    public S2Handler(final IRequestValidator requestValidator) {
       this.requestValidator = requestValidator;
    }

    public ValidatorResult validateRequest(final IRequest request) {

        return requestValidator.validateRequest(request);
    }






}
