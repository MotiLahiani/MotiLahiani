package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.validator.ParamTypesValidator;
import com.salt.interview.service2.data.validator.ValidatorResult;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;


@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class IntValidator implements ParamTypesValidator {

    private static volatile IntValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the IntValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static IntValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (IntValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new IntValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {
        //if (!org.apache.commons.validator.routines.IntegerValidator.getInstance().isValid(input.textValue())) {
        if( !input.isInt()) {
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid Int number but a %s type", input, input.getNodeType().name()));
        }
        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.Int.toString();}
}
