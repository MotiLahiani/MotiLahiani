package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ParamTypesValidator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ArrayValidator implements ParamTypesValidator {
    private static volatile ArrayValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the ArrayValidator.
     *
     * Use Lazy creation and double check locking
     */
    public static ArrayValidator getInstance() {
        if (VALIDATOR == null) {
            synchronized (ArrayValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new ArrayValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        if (!input.isArray()) {
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid Array but a %s type", input, input.getNodeType().name()));
        }
        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.Array.toString();}
}
