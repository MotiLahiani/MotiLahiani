package com.salt.interview.service2.data.validator;

public enum ValidatorResultStatus {

    valid("Valid"),
    abnormal("Abnormal");

    private final String status;

    ValidatorResultStatus(final String status) {
        this.status = status;
    }

    public String getTypeString() {
        return this.status;
    }
}
