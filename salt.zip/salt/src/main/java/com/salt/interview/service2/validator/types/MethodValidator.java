package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.Method;
import com.salt.interview.service2.data.validator.AbnormalField;
import com.salt.interview.service2.validator.ParamTypesValidator;
import com.salt.interview.service2.data.validator.ValidatorResult;

public class MethodValidator implements ParamTypesValidator {
    private static volatile MethodValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the MethodValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static MethodValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (MethodValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new MethodValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {
        try {
            Method.valueOf(input.textValue());
        } catch(IllegalArgumentException e) {
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] not a valid Method, should be one of [%s] error[%s]", input, Method.values().toString(), e.getMessage()));

        }

        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return "Method";}
}
