package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ParamTypesValidator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.UUID;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UuidValidator implements ParamTypesValidator {
    private static volatile UuidValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the UuidValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static UuidValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (UuidValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new UuidValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        try{
            UUID.fromString(input.textValue());
            //do something
        } catch (IllegalArgumentException exception){
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid UUID but a %s type", input, input.getNodeType().name()));
        }

        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.UUID.toString();}
}
