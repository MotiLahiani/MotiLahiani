package com.salt.interview.service2.validator.schemaValidator;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.service2.data.validator.ValidatorResult;


public interface SchemaTypeValidator {
    ValidatorResult doValidate(BaseSchema schema, JsonNode node);
}
