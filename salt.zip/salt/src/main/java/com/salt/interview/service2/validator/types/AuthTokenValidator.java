package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.data.validator.ValidatorResult;
import com.salt.interview.service2.validator.ParamTypesValidator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AuthTokenValidator implements ParamTypesValidator {
    private static String PATTERN_START_WITH = "Bearer ";
    private static String PATTERN = "^" +PATTERN_START_WITH + "[a-zA-Z|0-9]*$";
    private static Pattern pattern = Pattern.compile(PATTERN);
    private static volatile AuthTokenValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the AuthTokenValidator.
     *
     * Use Lazy creation and double check locking
     */
    public static AuthTokenValidator getInstance() {
        if (VALIDATOR == null) {
            synchronized (AuthTokenValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new AuthTokenValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        if (!pattern.matcher(input.textValue()).matches()) {

            return new ValidatorResult().addAbnormalField(name, getErrors(input.textValue()));
        }
        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.Array.toString();}

    private String getErrors(final String input) {
        List<String> res = new ArrayList<>();

        res.add(String.format("[%s] is not a valid Auth-Token", input));

        if(!input.startsWith(PATTERN_START_WITH)) {
            res.add("Token doesn't start with " + PATTERN_START_WITH);
        }

        Set<Character> notAllowedChar = input.chars().mapToObj(c -> (char) c).filter(c -> !Character.isDigit(c) && !Character.isAlphabetic(c)).collect(Collectors.toSet());
        if (notAllowedChar.size() > 0) {
            res.add("Token contain the following illegal character(s) " + notAllowedChar);
        }


        return res.size() == 1 ? res.get(0) : res.stream().collect(Collectors.joining(","));
    }
}
