package com.salt.interview.service2.validator;

import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.SchemaType;
import com.salt.interview.service2.validator.schemaValidator.ArraySchemaValidator;
import com.salt.interview.service2.validator.schemaValidator.MethodSchemaValidator;
import com.salt.interview.service2.validator.schemaValidator.ObjectSchemaValidator;
import com.salt.interview.service2.validator.schemaValidator.SchemaTypeValidator;
import com.salt.interview.service2.validator.schemaValidator.ValueSchemaValidator;
import com.salt.interview.service2.validator.types.ArrayValidator;
import com.salt.interview.service2.validator.types.AuthTokenValidator;
import com.salt.interview.service2.validator.types.BooleanValidator;
import com.salt.interview.service2.validator.types.DateValidator;
import com.salt.interview.service2.validator.types.DefaultValidator;
import com.salt.interview.service2.validator.types.EmailValidator;
import com.salt.interview.service2.validator.types.IntValidator;
import com.salt.interview.service2.validator.types.ListValidator;
import com.salt.interview.service2.validator.types.MethodValidator;
import com.salt.interview.service2.validator.types.StringValidator;
import com.salt.interview.service2.validator.types.UuidValidator;
import org.springframework.stereotype.Component;

@Component
public class ValidatorFactory {

    public static ParamTypesValidator getParamTypeValidator(final ParamsTypes type) {

        ParamTypesValidator paramTypesValidator = null;

        switch(type) {
            case Int:
                paramTypesValidator = IntValidator.getInstance();
                break;

            case String:
                paramTypesValidator = StringValidator.getInstance();
                break;

            case Boolean:
                paramTypesValidator = BooleanValidator.getInstance();
                break;

            case Date:
                paramTypesValidator = DateValidator.getInstance();
                break;

            case Email:
                paramTypesValidator = EmailValidator.getInstance();
                break;

            case UUID:
                paramTypesValidator = UuidValidator.getInstance();
                break;

            case AuthToken:
                paramTypesValidator = AuthTokenValidator.getInstance();
                break;

            case List:
                paramTypesValidator = ListValidator.getInstance();
                break;

            case Method:
                paramTypesValidator = MethodValidator.getInstance();
                break;

            case Array:
                paramTypesValidator = ArrayValidator.getInstance();
                break;

            default:
                paramTypesValidator = DefaultValidator.getInstance();
                break;
        }
        return paramTypesValidator;
    }

    public static SchemaTypeValidator getValidator(final SchemaType type) {

        SchemaTypeValidator validator = null;

        switch(type) {
            case VALUE:
                validator = ValueSchemaValidator.getInstance();
                break;

            case METHOD:
                validator = MethodSchemaValidator.getInstance();
            break;

            case ARRAY:
                validator = ArraySchemaValidator.getInstance();
                break;

            case OBJECT:
                validator = ObjectSchemaValidator.getInstance();
                break;

            default:
                //todo
                break;
        }
        return validator;
    }
}
