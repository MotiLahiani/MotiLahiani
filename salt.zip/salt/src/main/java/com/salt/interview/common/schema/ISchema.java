package com.salt.interview.common.schema;


import com.salt.interview.data.common.schema.BaseSchema;

import java.util.List;

public interface ISchema {
    String getName();
    List<BaseSchema> getRequiredItems();
}
