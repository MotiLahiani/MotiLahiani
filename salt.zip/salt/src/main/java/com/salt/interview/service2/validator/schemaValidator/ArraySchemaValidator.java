package com.salt.interview.service2.validator.schemaValidator;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.schema.ArraySchema;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.data.common.SchemaType;
import com.salt.interview.service2.data.validator.ValidatorResult;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@EqualsAndHashCode(callSuper = true)
@ToString
public class ArraySchemaValidator extends ObjectSchemaValidator {

    private Integer containOptional;

    private static volatile ArraySchemaValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the ArraySchemaValidator.
     *
     * Use Lazy creation and double check locking
     */
    public static ArraySchemaValidator getInstance() {
        if (VALIDATOR == null) {
            synchronized (ArraySchemaValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new ArraySchemaValidator();
                }
            }
        }
        return VALIDATOR;
    }


    @Override
    public ValidatorResult doValidate(BaseSchema schema, JsonNode node) {
        ValidatorResult validatorResult = new ValidatorResult();

        if (!node.isArray()) {
            return validatorResult.addAbnormalField(schema.getName(),
                            String.format("[%s] is not a valid Array but a %s type", node, node.getNodeType().name()));

        }

        this.containRequired = 0;
        this.containOptional = 0;

        ArraySchema arraySchema = (ArraySchema)schema;

        // 1. check minimum of array size by required
        checkArrayMinimum(arraySchema, node, validatorResult);
        // 2. check maximum of array size by required + optional
        checkArrayMaximum(arraySchema, node, validatorResult);
        // 3. check all required exists and correct type
        checkRequired(arraySchema, node, validatorResult);
        // 4. check for each existing optional if type correct
        checkOptional(arraySchema, node, validatorResult);

        return validatorResult;

    }

    private void checkArrayMinimum(ArraySchema arraySchema, JsonNode node, ValidatorResult validatorResult) {
        if(node.size() < arraySchema.getRequiredItems().size()) {
            validatorResult.addAbnormalField(arraySchema.getName(),
                    String.format("[%s] is not a valid Array minimum items need to be [%d] but found [%d]",
                            arraySchema.getName(),
                            arraySchema.getRequiredItems().size(),
                            node.size()));
        }
    }

    private void checkArrayMaximum(ArraySchema arraySchema, JsonNode node, ValidatorResult validatorResult) {
        int maxRequired = arraySchema.getRequiredItems().size() + arraySchema.getOptionalItems().size();

        if (node.size() > maxRequired) {
            validatorResult.addAbnormalField(arraySchema.getName(),
                    String.format("[%s] is not a valid Array maximum items need to be [%d] but found [%d]",
                            node,
                            maxRequired,
                            node.size()));
        }
    }

   private void checkOptional(ArraySchema arraySchema, JsonNode node, ValidatorResult validatorResult) {
       checkItems(arraySchema.getName(), node, validatorResult, arraySchema.getOptionalItems(), containOptional, false);
    }

//    private void checkArrayNotContainOther(ArraySchema arraySchema, JsonNode node, ValidatorResult validatorResult) {
//
//        int actualContain = containRequired + containOptional;
//        if (actualContain != node.size()) {
//            validatorResult.addAbnormalField(arraySchema.getName(),
//                    String.format("[%s] array contain other item(s) [%s]",
//                            arraySchema.getFullPath(), node.size() -  actualContain));
//        }
//    }

    @Override
    protected boolean isItemTypeAllowed(BaseSchema schema, ValidatorResult validatorResult) {
        if (!schema.getType().equals(SchemaType.VALUE)) {
            validatorResult.addAbnormalField(schema.getName(),
                    String.format("[%s] array contain not allowed type item [%s]",
                            schema.getFullPath(), schema.getType()));
            return false;
        }

        return true;
    }


}
