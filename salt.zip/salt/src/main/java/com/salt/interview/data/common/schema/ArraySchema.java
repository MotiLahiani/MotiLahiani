package com.salt.interview.data.common.schema;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.SchemaType;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonPropertyOrder({"type", "name", "fullPath", "paramsTypes", "requiredItems", "optionalItems"})
public class ArraySchema extends ObjectSchema {

    @Setter(AccessLevel.NONE)
    @Builder.Default
    protected List<BaseSchema> optionalItems= new ArrayList<>();;


    @Override
    public SchemaType getType() {
        return SchemaType.ARRAY;
    }

}
