package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.validator.ParamTypesValidator;
import com.salt.interview.service2.data.validator.ValidatorResult;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class BooleanValidator implements ParamTypesValidator {

    private static volatile BooleanValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the BooleanValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static BooleanValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (BooleanValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new BooleanValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        if (!input.isBoolean()) {
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid Boolean but a %s type", input, input.getNodeType().name()));
        }
        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.Boolean.toString();}
}
