package com.salt.interview.s1;

import com.salt.interview.data.module.SaltModule;
import com.salt.interview.common.schema.ISchema;
import com.salt.interview.db.SchemaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class S1Handler {

    private final Transformer transformer;
    private final SchemaRepository schemaRepository;
    public S1Handler(final Transformer transformer, final SchemaRepository schemaRepository) {
        this.transformer = transformer;
        this.schemaRepository = schemaRepository;
    }

    public void handleModules(Set<SaltModule> modules) {
        List<ISchema> schemas = modules.parallelStream()
                .filter(Objects::nonNull)
                .map(this::createSchema)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        this.schemaRepository.insertAll(schemas);

    }

    private ISchema createSchema(SaltModule module){
            return this.transformer.transform(module);
    }
}
