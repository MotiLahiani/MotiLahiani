package com.salt.interview.db;

import com.salt.interview.common.schema.ISchema;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class SchemaRepositoryImpl implements SchemaRepository {

    private final Map<String, ISchema> repo;

    public SchemaRepositoryImpl() {
        repo = new HashMap<>();
    }

    @Override
    public boolean insert(ISchema schema) {
        repo.put(schema.getName(), schema);
        return true;
    }

    @Override
    public boolean insertAll(List<ISchema> schemas) {

        schemas.stream().forEach(schema -> insert(schema));
        return true;
    }

    @Override
    public boolean remove(String key) {
        repo.remove(key);
        return true;
    }

    @Override
    public boolean remove(ISchema schema) {
        repo.remove(schema.getName());
        return false;
    }

    @Override
    public ISchema get(String key) {
        return repo.get(key);
    }
}
