package com.salt.interview.service2.validator.schemaValidator;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public abstract class SchemaTypeValidatorAbs implements SchemaTypeValidator {

}
