package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.service2.validator.ParamTypesValidator;
import com.salt.interview.service2.data.validator.ValidatorResult;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.regex.Pattern;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EmailValidator implements ParamTypesValidator {
    private static final String PATTERN = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:\\.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(PATTERN);

    private static volatile EmailValidator VALIDATOR = null;

    /**
     * Return a singleton instance of this validator.
     * @return A singleton instance of the EmailValidator.
     *
     * Use Lazy creation and double check locking
     **/
    public static EmailValidator getInstance() {

        if (VALIDATOR == null) {
            synchronized (EmailValidator.class) {
                if (VALIDATOR == null) {
                    VALIDATOR = new EmailValidator();
                }
            }
        }
        return VALIDATOR;
    }

    @Override
    public ValidatorResult validateData(String name, JsonNode input) {

        if (!EMAIL_PATTERN.matcher(input.textValue()).matches()) {
            return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid email address", input));
        }
//        if (!org.apache.commons.validator.routines.EmailValidator.getInstance().isValid(input.textValue())) {
//             return new ValidatorResult().addAbnormalField(name, String.format("[%s] is not a valid email address", input));
//        }
        return SUCCESS_RESULT;
    }

    @Override
    public String validatorName() { return ParamsTypes.Email.toString();}

}
