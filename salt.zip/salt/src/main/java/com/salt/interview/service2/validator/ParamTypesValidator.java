package com.salt.interview.service2.validator;

import com.fasterxml.jackson.databind.JsonNode;
import com.salt.interview.service2.data.validator.ValidatorResult;

public interface ParamTypesValidator {

    ValidatorResult SUCCESS_RESULT = new ValidatorResult();

    ValidatorResult validateData(String name, JsonNode input);

    default String validatorName() { return "default-validator";}

    default ValidatorResult validateNotNull(String name, JsonNode input) {

        if (input.isNull()) {
            return new ValidatorResult().addAbnormalField(name, "input is null");
        }
        return SUCCESS_RESULT;
    }

    default ValidatorResult validate(String name, JsonNode input) {
        if (name == null) { return null;}

        ValidatorResult validatorResult = validateNotNull(name, input);

        if (validatorResult.getStatus().equals(ValidatorResult.Status.Success)) {
            validatorResult = validateData(name, input);
        }

        return validatorResult;
    }

}
