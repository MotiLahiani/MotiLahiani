package com.salt.interview.service2.validator;

import com.salt.interview.data.request.IRequest;
import com.salt.interview.service2.data.validator.ValidatorResult;

public interface IRequestValidator {
    ValidatorResult validateRequest(IRequest request);
}
