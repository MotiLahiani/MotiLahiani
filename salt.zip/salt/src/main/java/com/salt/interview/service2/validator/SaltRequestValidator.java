package com.salt.interview.service2.validator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.salt.interview.common.schema.ISchema;
import com.salt.interview.data.common.ParamsTypes;
import com.salt.interview.data.common.schema.BaseSchema;
import com.salt.interview.data.request.IRequest;
import com.salt.interview.db.SchemaRepository;
import com.salt.interview.service2.data.validator.ValidatorResult;
import org.springframework.stereotype.Component;

import java.util.Objects;


@Component
public class SaltRequestValidator implements IRequestValidator {

    private final ObjectMapper objectMapper;
    private final SchemaRepository schemaRepository;
    public SaltRequestValidator(final ObjectMapper objectMapper, final SchemaRepository schemaRepository) {
        this.objectMapper = objectMapper;
        this.schemaRepository = schemaRepository;
    }

    public ValidatorResult validateRequest(IRequest request) {
        ValidatorResult validatorResult = new ValidatorResult();

        if(!canStartValidate(request)) {
            return validatorResult.addAbnormalField("Request", "Request is null");
        }

        JsonNode root = objectMapper.valueToTree(request);

        if (Objects.isNull(root)) {
            return validatorResult.addAbnormalField("Request", "Request structure is not valid");
        }

        ISchema schema = this.schemaRepository.get(request.getPath());
        if (Objects.isNull(schema)) {
            return validatorResult.addAbnormalField("Request", "Request unknown");
        }

        for(BaseSchema bs : schema.getRequiredItems()) {
            JsonNode reqNode = root.path(bs.getFullPath());
//            for (ParamsTypes type : bs.getParamsTypes()) {
//                validatorResult.add(ValidatorFactory.getParamTypeValidator(type).validate(bs.getName(), reqNode));
//            }

            validatorResult.add(ValidatorFactory.getValidator(bs.getType()).doValidate(bs, reqNode));
        }


        return validatorResult;
    }


    private boolean canStartValidate(IRequest request) {
        return request != null ? true : false;
    }


}
