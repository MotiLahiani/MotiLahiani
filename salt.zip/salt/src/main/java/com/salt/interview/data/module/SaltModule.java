package com.salt.interview.data.module;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.salt.interview.data.common.Method;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"path", "method", "query_params", "headers", "body"})
public class SaltModule {
    @JsonProperty(required = true)
    private String path;

    @JsonProperty(required = true)
    private Method method;

    @JsonProperty(value="query_params", required = true)
    private List<Field> queryParams;

    @JsonProperty(required = true)
    private List<Field> headers;

    @JsonProperty(required = true)
    private List<Field> body;
}
