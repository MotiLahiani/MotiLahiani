package com.salt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication(scanBasePackages = "com.salt")
@ConfigurationPropertiesScan
public class SaltApplication {

    public static void main(String[] args) {
        SpringApplication.run(SaltApplication.class, args);
    }
}
