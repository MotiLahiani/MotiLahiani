package com.salt.interview.service2.validator.types;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.salt.interview.service2.data.validator.ValidatorResult;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;


class IntValidatorTest {

    @Test
    void testInt() throws JsonProcessingException {
        String jsonString = "{\"k1\":\"1\",\"k2\":2, \"k3\": \"Bearer ebb3c-bbe938c4776bd22a4ec2ea8b2ca\"}";
        ObjectMapper mapper = new ObjectMapper();

        JsonNode actualObj = mapper.readTree(jsonString);
        JsonNode jsonNode1 = actualObj.get("k1");
        JsonNode jsonNode2 = actualObj.get("k2");
        JsonNode jsonNode3 = actualObj.get("k3");
//        ValidatorResult vr1 = IntValidator.getInstance().validate("test1", jsonNode1);
//        ValidatorResult vr2 = IntValidator.getInstance().validate("test2", jsonNode2);
//
//        ValidatorResult vr3 = StringValidator.getInstance().validate("test1", jsonNode1);
//        ValidatorResult vr4 = StringValidator.getInstance().validate("test2", jsonNode2);

        ValidatorResult vr5 = AuthTokenValidator.getInstance().validate("test3", jsonNode3);
    }

}