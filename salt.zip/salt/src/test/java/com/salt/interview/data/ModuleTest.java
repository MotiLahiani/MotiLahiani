package com.salt.interview.data;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.salt.interview.data.module.SaltModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ModuleTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void test() throws JsonProcessingException {
        String m = "{\n" +
                "\t\"path\": \"/users/info\",\n" +
                "\t\"method\": \"GET\", \n" +
                "\t\"query_params\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"name\": \"with_extra_data\",\n" +
                "\t\t\t\"types\": [\"Boolean\"],\n" +
                "\t\t\t\"required\": false\n" +
                "\t\t},\n" +
                "\t\t{\n" +
                "\t\t\t\"name\": \"user_id\",\n" +
                "\t\t\t\"types\": [\"String\", \"UUID\"],\n" +
                "\t\t\t\"required\": false\n" +
                "\t\t}\n" +
                "\t],\n" +
                "\t\"headers\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"name\": \"Authorization\",\n" +
                "\t\t\t\"types\": [\"String\", \"Auth-Token\"],\n" +
                "\t\t\t\"required\": true\n" +
                "\t\t}\n" +
                "\t],\n" +
                "\t\"body\": []\n" +
                "}";
        ObjectMapper om = new ObjectMapper();
        SaltModule module = om.readValue(m, SaltModule.class);
    }

}