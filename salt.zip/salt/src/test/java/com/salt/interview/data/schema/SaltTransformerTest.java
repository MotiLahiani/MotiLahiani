package com.salt.interview.data.schema;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class SaltTransformerTest {

    @Test
    void test() throws IOException {
        String jsonString = "{\n" +
                "\t\"path\": \"/users/info\",\n" +
                "\t\"method\": \"GET\", \n" +
                "\t\"query_params\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"name\": \"with_extra_data\",\n" +
                "\t\t\t\"types\": [\"Boolean\"],\n" +
                "\t\t\t\"required\": false\n" +
                "\t\t},\n" +
                "\t\t{\n" +
                "\t\t\t\"name\": \"user_id\",\n" +
                "\t\t\t\"types\": [\"String\", \"UUID\"],\n" +
                "\t\t\t\"required\": false\n" +
                "\t\t}\n" +
                "\t],\n" +
                "\t\"headers\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"name\": \"Authorization\",\n" +
                "\t\t\t\"types\": [\"String\", \"Auth-Token\"],\n" +
                "\t\t\t\"required\": true\n" +
                "\t\t}\n" +
                "\t],\n" +
                "\t\"body\": []\n" +
                "}";

        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getFactory();
        JsonParser parser = factory.createParser(jsonString);
        JsonNode actualObj = mapper.readTree(parser);
        int ch = actualObj.size();


    }

}